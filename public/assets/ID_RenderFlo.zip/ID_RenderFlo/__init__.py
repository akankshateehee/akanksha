bl_info = {
    "name": "ID RenderFlo",
    "author": "Sahitya Kashyap (sahityakashyap.in)",
    "version": (2, 2, 0),
    "blender": (3, 6, 0),  # Compatible minimum floor; runs seamlessly on 4.x and 5.x
    "location": "View3D > Sidebar (N-Panel) > ID RenderFlo  &  File > Import > CAD (.step/.stp/.iges)",
    "description": "Universal Industrial Design Studio & CAD Pipeline for Blender 3.6 - 5.2.2+: Isolated OpenCASCADE STEP/CAD Importer, Multi-Studio Cameras, In-Panel CMF Cloner, and Non-Blocking GPU Batch Queue",
    "doc_url": "https://sahityakashyap.in",
    "tracker_url": "https://sahityakashyap.in",
    "category": "Render",
}

import bpy
import os
import sys
import site
import json
import math
import tempfile
import subprocess
from mathutils import Vector
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ImportHelper

MASTER_LIGHT_COLL = "_RENDERFLO_LIGHTS_MASTER_"
MASTER_CAM_COLL = "_RENDERFLO_CAMERAS_"
TARGET_EMPTY_NAME = "RenderFlo_Product_Target"
GROUND_PLANE_NAME = "RenderFlo_Shadow_Floor"
BACKDROP_OBJ_NAME = "RenderFlo_Curved_Backdrop"

_IS_INTERNAL_UPDATE = False
_CAD_ENGINE_AVAILABLE = None

# ------------------------------------------------------------------------
# Adaptive Version-Safe Mesh Import Dispatcher (3.6 - 5.2.2+)
# ------------------------------------------------------------------------

def safe_import_stl(filepath):
    if hasattr(bpy.ops.wm, "stl_import"):
        bpy.ops.wm.stl_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "stl"):
        bpy.ops.import_mesh.stl(filepath=filepath)

def safe_import_obj(filepath):
    if hasattr(bpy.ops.wm, "obj_import"):
        bpy.ops.wm.obj_import(filepath=filepath)
    elif hasattr(bpy.ops.import_scene, "obj"):
        bpy.ops.import_scene.obj(filepath=filepath)

def safe_import_ply(filepath):
    if hasattr(bpy.ops.wm, "ply_import"):
        bpy.ops.wm.ply_import(filepath=filepath)
    elif hasattr(bpy.ops.import_mesh, "ply"):
        bpy.ops.import_mesh.ply(filepath=filepath)

# ------------------------------------------------------------------------
# Universal Cross-Version CAD Kernel Bootstrapper
# ------------------------------------------------------------------------

def get_cad_env_dir():
    """Returns a version-specific persistent directory isolated from Blender's installation."""
    py_ver = f"py{sys.version_info.major}_{sys.version_info.minor}"
    return bpy.utils.user_resource('SCRIPTS', path=os.path.join("id_renderflo_engine", py_ver), create=True)

def is_cad_engine_ready(force_recheck=False):
    global _CAD_ENGINE_AVAILABLE
    if _CAD_ENGINE_AVAILABLE is not None and not force_recheck:
        return _CAD_ENGINE_AVAILABLE

    env_dir = get_cad_env_dir()
    search_dirs = [env_dir]
    try:
        us = site.getusersitepackages()
        if us and os.path.isdir(us):
            search_dirs.append(us)
    except Exception:
        pass

    for d in search_dirs:
        if (
            os.path.isdir(os.path.join(d, "cascadio")) or
            os.path.isdir(os.path.join(d, "gmsh")) or
            os.path.isfile(os.path.join(d, "gmsh.py"))
        ):
            _CAD_ENGINE_AVAILABLE = True
            return True

    _CAD_ENGINE_AVAILABLE = False
    return False

def bootstrap_cad_engine():
    py_exec = sys.executable
    target_dir = get_cad_env_dir()
    os.makedirs(target_dir, exist_ok=True)

    try:
        subprocess.call([py_exec, "-m", "ensurepip", "--user"])
    except Exception:
        pass

    for pkg in ("cascadio", "gmsh"):
        res = subprocess.run(
            [py_exec, "-m", "pip", "install", "--target", target_dir, "--upgrade", pkg],
            capture_output=True, text=True
        )
        if res.returncode == 0:
            break

    return is_cad_engine_ready(force_recheck=True)

# ------------------------------------------------------------------------
# Isolated Process CAD Worker (Crash-Proof Across All Blender Versions)
# ------------------------------------------------------------------------

UNIVERSAL_WORKER_CODE = r"""
import sys
import os
import math

env_dir = sys.argv[1]
cad_filepath = sys.argv[2]
out_file = sys.argv[3]
lin_tol = float(sys.argv[4])
ang_rad = float(sys.argv[5])

if env_dir and os.path.isdir(env_dir) and env_dir not in sys.path:
    sys.path.insert(0, env_dir)

try:
    import site
    us = site.getusersitepackages()
    if us and os.path.isdir(us) and us not in sys.path:
        sys.path.insert(0, us)
except Exception:
    pass

ext = os.path.splitext(cad_filepath)[1].lower()

converted = False
if ext in {'.step', '.stp'} and out_file.endswith('.glb'):
    try:
        import cascadio
        cascadio.step_to_glb(cad_filepath, out_file, lin_tol, ang_rad)
        converted = True
    except Exception:
        converted = False

if not converted:
    import gmsh
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("RenderFlo_CAD")
        gmsh.model.occ.importShapes(cad_filepath)
        gmsh.model.occ.synchronize()
        ang_deg = math.degrees(ang_rad)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", max(6, int(360.0 / max(ang_deg, 2.0))))
        gmsh.option.setNumber("Mesh.MeshSizeMax", max(lin_tol * 25.0, 0.5))
        gmsh.option.setNumber("Mesh.MeshSizeMin", max(lin_tol * 0.5, 0.005))
        gmsh.model.mesh.generate(2)
        gmsh.write(out_file)
    finally:
        gmsh.finalize()
"""

def execute_universal_cad_import(context, filepath, lin_tol, ang_rad):
    if not is_cad_engine_ready():
        success = bootstrap_cad_engine()
        if not success:
            raise RuntimeError("Could not initialize CAD kernel. Please check internet connection on initial setup.")

    base_name = os.path.splitext(os.path.basename(filepath))[0]
    ext = os.path.splitext(filepath)[1].lower()
    tmp_dir = tempfile.gettempdir()
    worker_script = os.path.join(tmp_dir, "_renderflo_worker.py")
    out_glb = os.path.join(tmp_dir, f"_rf_{base_name}.glb")
    out_stl = os.path.join(tmp_dir, f"_rf_{base_name}.stl")

    with open(worker_script, "w", encoding="utf-8") as f:
        f.write(UNIVERSAL_WORKER_CODE)

    for p in (out_glb, out_stl):
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass

    env_dir = get_cad_env_dir()
    target_out = out_glb if ext in {'.step', '.stp'} else out_stl

    res = subprocess.run(
        [sys.executable, worker_script, env_dir, filepath, target_out, str(lin_tol), str(ang_rad)],
        capture_output=True, text=True
    )

    if (res.returncode != 0 or not os.path.exists(target_out)) and target_out == out_glb:
        target_out = out_stl
        res = subprocess.run(
            [sys.executable, worker_script, env_dir, filepath, target_out, str(lin_tol), str(ang_rad)],
            capture_output=True, text=True
        )

    if res.returncode == 0 and os.path.exists(target_out):
        before = set(context.scene.objects)
        if target_out.endswith(".glb"):
            bpy.ops.import_scene.gltf(filepath=target_out)
        else:
            safe_import_stl(target_out)

        try:
            os.remove(target_out)
        except OSError:
            pass

        return [o for o in context.scene.objects if o not in before]

    err = (res.stderr or res.stdout or "Unknown conversion error").strip()
    raise RuntimeError(f"CAD Conversion failed: {err[-300:]}")

# ------------------------------------------------------------------------
# GPU Hardware & Quality Settings
# ------------------------------------------------------------------------

def configure_cycles_gpu(scene, force_gpu=True):
    scene.render.engine = 'CYCLES'
    if not hasattr(scene, "cycles"):
        return "Cycles not available"

    if not force_gpu:
        scene.cycles.device = 'CPU'
        return "CPU"

    scene.cycles.device = 'GPU'
    try:
        prefs = bpy.context.preferences
        cprefs = prefs.addons['cycles'].preferences
        preferred_backends = ['OPTIX', 'CUDA', 'HIP', 'METAL', 'ONEAPI']
        chosen_backend = None

        for backend in preferred_backends:
            try:
                cprefs.compute_device_type = backend
                cprefs.get_devices()
                gpu_devs = [d for d in cprefs.devices if d.type != 'CPU']
                if gpu_devs:
                    chosen_backend = backend
                    for d in cprefs.devices:
                        d.use = (d.type != 'CPU')
                    break
            except Exception:
                continue

        if chosen_backend:
            return f"GPU ({chosen_backend})"
    except Exception:
        pass

    return "GPU (Active)"

def apply_render_quality_settings(scene, samples):
    if hasattr(scene, "cycles"):
        scene.cycles.samples = samples
        scene.cycles.preview_samples = scene.rf_viewport_samples
        scene.cycles.use_adaptive_sampling = True
        scene.cycles.adaptive_threshold = scene.rf_noise_threshold
        scene.cycles.use_denoising = scene.rf_use_denoiser

# ------------------------------------------------------------------------
# Aspect Ratio & Studio Configurations
# ------------------------------------------------------------------------

ASPECT_PRESETS = [
    ('16_9', "16:9 (Widescreen)", "16:9 Landscape", 16, 9),
    ('1_1', "1:1 (Square)", "1:1 Square", 1, 1),
    ('4_5', "4:5 (Portrait)", "4:5 Portrait", 4, 5),
    ('9_16', "9:16 (Vertical)", "9:16 Vertical", 9, 16),
    ('4_3', "4:3 (Standard)", "4:3 Standard", 4, 3),
    ('3_2', "3:2 (Photography)", "3:2 Photo", 3, 2),
    ('21_9', "21:9 (Ultrawide)", "21:9 Cinematic", 21, 9),
    ('CUSTOM', "Custom Resolution", "Enter custom pixel dimensions", 0, 0),
]

def update_studio_aspect_ratio(self, context):
    global _IS_INTERNAL_UPDATE
    if _IS_INTERNAL_UPDATE:
        return
    _IS_INTERNAL_UPDATE = True
    try:
        if self.aspect_preset != 'CUSTOM':
            for code, _, _, w, h in ASPECT_PRESETS:
                if code == self.aspect_preset:
                    base = self.base_resolution
                    if w >= h:
                        self.res_x = base
                        self.res_y = int(round(base * (h / w)))
                    else:
                        self.res_y = base
                        self.res_x = int(round(base * (w / h)))
                    break

        if context and context.scene:
            scene = context.scene
            if 0 <= scene.rf_studio_index < len(scene.rf_studios):
                if scene.rf_studios[scene.rf_studio_index] == self and self.use_resolution:
                    scene.render.resolution_x = self.res_x
                    scene.render.resolution_y = self.res_y
                    scene.render.resolution_percentage = self.res_scale
                    if scene.camera and scene.camera.data:
                        scene.camera.data.sensor_fit = 'VERTICAL' if (self.res_y > self.res_x) else 'HORIZONTAL'
    finally:
        _IS_INTERNAL_UPDATE = False

def update_global_render_settings(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    scene = context.scene
    configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
    apply_render_quality_settings(scene, scene.rf_render_samples)

# ------------------------------------------------------------------------
# Data Structures
# ------------------------------------------------------------------------

class RENDERFLO_PG_collection_state(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Collection Name")
    hide_viewport: bpy.props.BoolProperty(name="Hide Viewport")
    hide_render: bpy.props.BoolProperty(name="Hide Render")

class RENDERFLO_PG_material_slot(bpy.types.PropertyGroup):
    slot_index: bpy.props.IntProperty(name="Slot Index")
    material_name: bpy.props.StringProperty(name="Material Name")

class RENDERFLO_PG_object_materials(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    slots: bpy.props.CollectionProperty(type=RENDERFLO_PG_material_slot)

class RENDERFLO_PG_object_transform(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))

class RENDERFLO_PG_cmf_preset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="CMF Name", default="CMF_01")
    batch_enabled: bpy.props.BoolProperty(name="Include in Matrix Batch", default=True)
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)

class RENDERFLO_PG_light_state(bpy.types.PropertyGroup):
    light_obj_name: bpy.props.StringProperty(name="Light Object")
    location: bpy.props.FloatVectorProperty(size=3)
    rotation_euler: bpy.props.FloatVectorProperty(size=3)
    scale: bpy.props.FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))
    energy: bpy.props.FloatProperty(default=100.0)
    color: bpy.props.FloatVectorProperty(size=3, subtype='COLOR', default=(1.0, 1.0, 1.0))
    size: bpy.props.FloatProperty(default=1.0)
    hide_viewport: bpy.props.BoolProperty(default=False)
    hide_render: bpy.props.BoolProperty(default=False)

def get_cmf_enum_items(self, context):
    items = [('NONE', "-- Keep Current Materials --", "Do not override materials")]
    if context and getattr(context, "scene", None):
        for cmf in context.scene.rf_cmf_presets:
            items.append((cmf.name, f"CMF: {cmf.name}", f"Apply colorway '{cmf.name}'"))
    items.append(('CUSTOM', "Unique Studio CMF", "Store materials only for this Studio"))
    return items

def on_studio_camera_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    if self.camera_obj and self.camera_obj.type == 'CAMERA':
        context.scene.camera = self.camera_obj

def on_studio_cmf_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    apply_cmf_to_scene(context.scene, self)

def on_studio_image_style_change(self, context):
    if _IS_INTERNAL_UPDATE or not context or not context.scene:
        return
    if self.use_image_style:
        apply_image_style_to_scene(context.scene, self)

class RENDERFLO_PG_studio_item(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Studio Name", default="New Studio")
    render_enabled: bpy.props.BoolProperty(name="Include in Batch", default=True)

    camera_obj: bpy.props.PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA',
        update=on_studio_camera_change
    )

    aspect_preset: bpy.props.EnumProperty(
        name="Aspect Ratio",
        items=[(c, n, d) for c, n, d, _, _ in ASPECT_PRESETS],
        default='16_9',
        update=update_studio_aspect_ratio
    )
    base_resolution: bpy.props.IntProperty(name="Long Edge (px)", default=1920, min=128, max=16384, update=update_studio_aspect_ratio)
    res_x: bpy.props.IntProperty(name="Width (X)", default=1920, min=64, max=16384, update=update_studio_aspect_ratio)
    res_y: bpy.props.IntProperty(name="Height (Y)", default=1080, min=64, max=16384, update=update_studio_aspect_ratio)
    res_scale: bpy.props.IntProperty(name="Resolution %", default=100, min=10, max=400, subtype='PERCENTAGE', update=update_studio_aspect_ratio)

    use_custom_samples: bpy.props.BoolProperty(
        name="Custom Samples for Studio",
        description="Override global samples specifically for this Studio",
        default=False
    )
    studio_samples: bpy.props.IntProperty(
        name="Studio Samples",
        default=256,
        min=1,
        max=65536
    )

    light_collection_name: bpy.props.StringProperty(name="Studio Light Collection")
    world_name: bpy.props.StringProperty(name="World")

    cmf_mode: bpy.props.EnumProperty(name="CMF Variation", items=get_cmf_enum_items, update=on_studio_cmf_change)

    exposure: bpy.props.FloatProperty(name="Exposure", default=0.0, min=-10.0, max=10.0, update=on_studio_image_style_change)
    film_transparent: bpy.props.BoolProperty(name="Transparent PNG", default=True, update=on_studio_image_style_change)

    use_camera: bpy.props.BoolProperty(name="Camera", default=True)
    use_resolution: bpy.props.BoolProperty(name="Aspect Ratio & Res", default=True)
    use_lights: bpy.props.BoolProperty(name="Lights & HDRI", default=True)
    use_materials: bpy.props.BoolProperty(name="CMF (Materials)", default=True)
    use_collections: bpy.props.BoolProperty(name="Model Sets", default=True)
    use_transforms: bpy.props.BoolProperty(name="Exploded / Part Positions", default=False)
    use_image_style: bpy.props.BoolProperty(name="Image Style", default=True)

    collection_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_collection_state)
    object_materials: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_materials)
    object_transforms: bpy.props.CollectionProperty(type=RENDERFLO_PG_object_transform)
    light_states: bpy.props.CollectionProperty(type=RENDERFLO_PG_light_state)

# ------------------------------------------------------------------------
# Material & CAD Import Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_clone_active_material(bpy.types.Operator):
    bl_idname = "renderflo.clone_active_material"
    bl_label = "Clone Slot Material as New"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.active_material:
            self.report({'WARNING'}, "Select an object with an active material slot first.")
            return {'CANCELLED'}

        orig_mat = obj.active_material
        new_mat = orig_mat.copy()
        new_mat.name = f"{orig_mat.name}_Var"
        obj.active_material = new_mat
        self.report({'INFO'}, f"Cloned material to '{new_mat.name}' on {obj.name}")
        return {'FINISHED'}

class RENDERFLO_OT_bootstrap_cad_kernel(bpy.types.Operator):
    bl_idname = "renderflo.bootstrap_cad_kernel"
    bl_label = "Verify & Download CAD Engine"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if bootstrap_cad_engine():
            for area in context.screen.areas:
                area.tag_redraw()
            self.report({'INFO'}, "ID RenderFlo: CAD Kernel successfully initialized!")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to initialize CAD engine. Check internet connection for initial setup.")
            return {'CANCELLED'}

class RENDERFLO_OT_import_cad(bpy.types.Operator, ImportHelper):
    bl_idname = "renderflo.import_cad"
    bl_label = "Import CAD (ID RenderFlo)"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".step"
    filter_glob: bpy.props.StringProperty(
        default="*.step;*.stp;*.iges;*.igs;*.stl;*.obj;*.fbx;*.glb;*.gltf;*.ply",
        options={'HIDDEN'},
        maxlen=255,
    )

    tess_preset: bpy.props.EnumProperty(
        name="Tessellation Quality",
        items=[
            ('ULTRA', "Ultra Fine (0.02mm)", "Highest accuracy for macro product shots"),
            ('HIGH', "High Quality (0.08mm)", "Balanced smooth fillets and polycount"),
            ('MEDIUM', "Medium (0.25mm)", "Optimized performance for large assemblies"),
            ('CUSTOM', "Custom Tolerances", "Manually specify linear and angular deflection"),
        ],
        default='HIGH'
    )
    linear_deflection: bpy.props.FloatProperty(name="Linear Deflection (mm)", default=0.08, min=0.001, max=10.0)
    angular_deflection: bpy.props.FloatProperty(name="Angular Deflection (deg)", default=15.0, min=1.0, max=90.0)
    up_axis: bpy.props.EnumProperty(
        name="CAD Up-Axis",
        items=[
            ('Y_UP', "Y-Up (CAD Default)", "Rotate +90 deg on X to match Blender Z-Up"),
            ('Z_UP', "Z-Up (Rhino / Fusion / Blender)", "Keep Z as Up-Axis"),
        ],
        default='Y_UP'
    )
    unit_scale: bpy.props.EnumProperty(
        name="CAD Units",
        items=[
            ('MM_TO_M', "Millimeters -> Meters (0.001x)", "Scales metric CAD millimetres to Blender meters"),
            ('KEEP', "Keep Native Units (1.0x)", "Do not apply unit scale"),
            ('CM_TO_M', "Centimeters -> Meters (0.01x)", "Scale by 0.01"),
            ('INCH_TO_M', "Inches -> Meters (0.0254x)", "Scale by 0.0254"),
        ],
        default='MM_TO_M'
    )
    center_xy: bpy.props.BoolProperty(name="Center Product on X/Y Origin", default=True)
    snap_to_ground: bpy.props.BoolProperty(name="Snap Base to Floor (Z = 0)", default=True)
    auto_smooth_normals: bpy.props.BoolProperty(name="Weighted Normals (Clean Fillets)", default=True)

    def draw(self, context):
        layout = self.layout
        ready = is_cad_engine_ready()

        box = layout.box()
        box.label(text="CAD Engine Ready" if ready else "CAD Engine will setup automatically on Import", icon='CHECKMARK' if ready else 'INFO')
        box.prop(self, "tess_preset", text="Quality")
        if self.tess_preset == 'CUSTOM':
            col = box.column(align=True)
            col.prop(self, "linear_deflection")
            col.prop(self, "angular_deflection")

        box2 = layout.box()
        box2.label(text="Orientation & Units", icon='ORIENTATION_GLOBAL')
        box2.prop(self, "up_axis")
        box2.prop(self, "unit_scale")

        box3 = layout.box()
        box3.label(text="Auto-Prep Alignment", icon='MOD_REMESH')
        box3.prop(self, "center_xy")
        box3.prop(self, "snap_to_ground")
        box3.prop(self, "auto_smooth_normals")

    def execute(self, context):
        filepath = self.filepath
        ext = os.path.splitext(filepath)[1].lower()
        base_name = os.path.splitext(os.path.basename(filepath))[0]

        if self.tess_preset == 'ULTRA':
            lin_tol, ang_tol = 0.02, 10.0
        elif self.tess_preset == 'HIGH':
            lin_tol, ang_tol = 0.08, 15.0
        elif self.tess_preset == 'MEDIUM':
            lin_tol, ang_tol = 0.25, 25.0
        else:
            lin_tol, ang_tol = self.linear_deflection, self.angular_deflection

        ang_rad = math.radians(ang_tol)
        before_objs = set(context.scene.objects)

        if ext in {'.step', '.stp', '.iges', '.igs'}:
            try:
                execute_universal_cad_import(context, filepath, lin_tol, ang_rad)
            except Exception as e:
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}
        elif ext == '.stl':
            safe_import_stl(filepath)
        elif ext == '.obj':
            safe_import_obj(filepath)
        elif ext == '.fbx':
            bpy.ops.import_scene.fbx(filepath=filepath)
        elif ext in {'.glb', '.gltf'}:
            bpy.ops.import_scene.gltf(filepath=filepath)
        elif ext == '.ply':
            safe_import_ply(filepath)
        else:
            self.report({'ERROR'}, f"Unsupported format: {ext}")
            return {'CANCELLED'}

        new_objs = [obj for obj in context.scene.objects if obj not in before_objs]
        if not new_objs:
            self.report({'WARNING'}, "No geometry found in CAD file.")
            return {'CANCELLED'}

        cad_coll = bpy.data.collections.new(f"CAD_{base_name}")
        context.scene.collection.children.link(cad_coll)
        for obj in new_objs:
            for c in list(obj.users_collection):
                c.objects.unlink(obj)
            cad_coll.objects.link(obj)

        root_objs = [obj for obj in new_objs if obj.parent not in new_objs]
        assembly_root = bpy.data.objects.new(f"Assembly_{base_name}", None)
        assembly_root.empty_display_type = 'ARROWS'
        assembly_root.empty_display_size = 0.2
        cad_coll.objects.link(assembly_root)

        for r_obj in root_objs:
            r_obj.parent = assembly_root

        if self.up_axis == 'Y_UP' and ext not in {'.glb', '.gltf'}:
            assembly_root.rotation_euler.x += math.radians(90.0)

        scale_map = {'MM_TO_M': 0.001, 'CM_TO_M': 0.01, 'INCH_TO_M': 0.0254, 'KEEP': 1.0}
        scale_factor = scale_map.get(self.unit_scale, 1.0)
        if scale_factor != 1.0:
            assembly_root.scale *= scale_factor

        context.view_layer.update()

        mesh_objs = [obj for obj in new_objs if obj.type == 'MESH']
        if self.auto_smooth_normals:
            for m_obj in mesh_objs:
                for poly in m_obj.data.polygons:
                    poly.use_smooth = True
                if not m_obj.data.has_custom_normals:
                    wn = m_obj.modifiers.new(name="RenderFlo_WeightedNormal", type='WEIGHTED_NORMAL')
                    wn.keep_sharp = True

        if mesh_objs and (self.center_xy or self.snap_to_ground):
            depsgraph = context.evaluated_depsgraph_get()
            min_x = min_y = min_z = float('inf')
            max_x = max_y = max_z = float('-inf')

            for m_obj in mesh_objs:
                eval_obj = m_obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    world_pt = eval_obj.matrix_world @ Vector(corner)
                    min_x, max_x = min(min_x, world_pt.x), max(max_x, world_pt.x)
                    min_y, max_y = min(min_y, world_pt.y), max(max_y, world_pt.y)
                    min_z, max_z = min(min_z, world_pt.z), max(max_z, world_pt.z)

            offset = Vector((0.0, 0.0, 0.0))
            if self.center_xy:
                offset.x = -((min_x + max_x) * 0.5)
                offset.y = -((min_y + max_y) * 0.5)
            if self.snap_to_ground:
                offset.z = -min_z

            assembly_root.location += offset
            context.view_layer.update()

            target = ensure_light_target(context)
            target.location = Vector((0.0, 0.0, (max_z - min_z) * 0.5 if self.snap_to_ground else (min_z + max_z) * 0.5))

        self.report({'INFO'}, f"ID RenderFlo: Imported '{base_name}' ({len(mesh_objs)} parts) into Model Set '{cad_coll.name}'")
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Studio Manager Helpers & Ground Plane / Backdrop
# ------------------------------------------------------------------------

def ensure_collection(scene, coll_name):
    coll = bpy.data.collections.get(coll_name)
    if not coll:
        coll = bpy.data.collections.new(coll_name)
        scene.collection.children.link(coll)
    elif coll.name not in scene.collection.children:
        try:
            scene.collection.children.link(coll)
        except Exception:
            pass
    return coll

def ensure_studio_light_collection(context, studio):
    master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
    if studio.light_collection_name:
        sub_coll = bpy.data.collections.get(studio.light_collection_name)
        if sub_coll:
            return sub_coll

    coll_name = f"Lights_{studio.name}"
    sub_coll = bpy.data.collections.get(coll_name)
    if not sub_coll:
        sub_coll = bpy.data.collections.new(coll_name)
    if sub_coll.name not in master_coll.children:
        try:
            master_coll.children.link(sub_coll)
        except Exception:
            pass
    studio.light_collection_name = sub_coll.name
    return sub_coll

def create_camera_for_studio(context, studio_name, match_viewport=True):
    scene = context.scene
    cam_coll = ensure_collection(scene, MASTER_CAM_COLL)

    cam_data = bpy.data.cameras.new(name=f"Cam_{studio_name}")
    cam_data.lens = 85.0
    cam_data.passepartout_alpha = 0.85

    cam_obj = bpy.data.objects.new(name=f"Cam_{studio_name}", object_data=cam_data)
    cam_coll.objects.link(cam_obj)

    placed = False
    if scene.camera and not match_viewport:
        cam_obj.matrix_world = scene.camera.matrix_world.copy()
        if scene.camera.data and hasattr(scene.camera.data, "lens"):
            cam_data.lens = scene.camera.data.lens
        placed = True

    if not placed and context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and space.region_3d:
                        cam_obj.matrix_world = space.region_3d.view_matrix.inverted()
                        placed = True
                        break
                if placed:
                    break

    if not placed:
        cam_obj.location = (0.0, -3.5, 1.5)
        cam_obj.rotation_euler = (math.radians(70.0), 0.0, 0.0)

    scene.camera = cam_obj
    return cam_obj

def ensure_light_target(context):
    target = bpy.data.objects.get(TARGET_EMPTY_NAME)
    if not target:
        target = bpy.data.objects.new(TARGET_EMPTY_NAME, None)
        target.empty_display_type = 'SPHERE'
        target.empty_display_size = 0.25
        target.location = (0.0, 0.0, 0.0)
        master_coll = ensure_collection(context.scene, MASTER_LIGHT_COLL)
        master_coll.objects.link(target)
    return target

def switch_exclusive_studio_lights(context, active_studio):
    scene = context.scene
    active_coll_name = active_studio.light_collection_name
    for s in scene.rf_studios:
        if s.light_collection_name:
            coll = bpy.data.collections.get(s.light_collection_name)
            if coll:
                is_current = (coll.name == active_coll_name)
                coll.hide_viewport = not is_current
                coll.hide_render = not is_current

def record_materials_into_collection(scene, mat_collection_prop):
    mat_collection_prop.clear()
    for obj in list(scene.objects):
        if obj.name in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
            continue
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'} and len(obj.material_slots) > 0:
            obj_item = mat_collection_prop.add()
            obj_item.object_name = obj.name
            for idx, slot in enumerate(obj.material_slots):
                slot_item = obj_item.slots.add()
                slot_item.slot_index = idx
                slot_item.material_name = slot.material.name if slot.material else ""

def restore_materials_from_collection(mat_collection_prop):
    for obj_item in mat_collection_prop:
        obj = bpy.data.objects.get(obj_item.object_name)
        if obj:
            for slot_item in obj_item.slots:
                if slot_item.slot_index < len(obj.material_slots):
                    mat = bpy.data.materials.get(slot_item.material_name) if slot_item.material_name else None
                    obj.material_slots[slot_item.slot_index].material = mat

def apply_cmf_to_scene(scene, studio):
    if not studio.use_materials or studio.cmf_mode == 'NONE':
        return
    if studio.cmf_mode == 'CUSTOM':
        restore_materials_from_collection(studio.object_materials)
    else:
        cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
        if cmf:
            restore_materials_from_collection(cmf.object_materials)

def apply_image_style_to_scene(scene, studio):
    scene.view_settings.exposure = studio.exposure
    scene.render.film_transparent = studio.film_transparent

def capture_studio_state(context, studio):
    global _IS_INTERNAL_UPDATE
    prev_flag = _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = True
    try:
        scene = context.scene
        ensure_studio_light_collection(context, studio)

        if scene.camera:
            studio.camera_obj = scene.camera
        studio.world_name = scene.world.name if scene.world else ""

        ignored_colls = {s.light_collection_name for s in scene.rf_studios if s.light_collection_name}
        ignored_colls.add(MASTER_LIGHT_COLL)
        ignored_colls.add(MASTER_CAM_COLL)

        studio.collection_states.clear()
        for coll in bpy.data.collections:
            if coll.name in ignored_colls:
                continue
            item = studio.collection_states.add()
            item.name = coll.name
            item.hide_viewport = coll.hide_viewport
            item.hide_render = coll.hide_render

        record_materials_into_collection(scene, studio.object_materials)
        if studio.cmf_mode not in {'NONE', 'CUSTOM'}:
            cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
            if cmf:
                record_materials_into_collection(scene, cmf.object_materials)

        studio.object_transforms.clear()
        for obj in list(scene.objects):
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'EMPTY'} and obj.name not in {TARGET_EMPTY_NAME, GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                t_item = studio.object_transforms.add()
                t_item.object_name = obj.name
                t_item.location = obj.location
                t_item.rotation_euler = obj.rotation_euler
                t_item.scale = obj.scale

        studio.light_states.clear()
        for obj in list(scene.objects):
            if obj.type == 'LIGHT':
                l_item = studio.light_states.add()
                l_item.light_obj_name = obj.name
                l_item.location = obj.location
                l_item.rotation_euler = obj.rotation_euler
                l_item.scale = obj.scale
                l_item.energy = obj.data.energy
                l_item.color = obj.data.color
                if hasattr(obj.data, "size"):
                    l_item.size = obj.data.size
                l_item.hide_viewport = obj.hide_get()
                l_item.hide_render = obj.hide_render
    finally:
        _IS_INTERNAL_UPDATE = prev_flag

def apply_studio_state(context, studio):
    global _IS_INTERNAL_UPDATE
    prev_flag = _IS_INTERNAL_UPDATE
    _IS_INTERNAL_UPDATE = True
    try:
        scene = context.scene

        if studio.use_camera and studio.camera_obj and studio.camera_obj.type == 'CAMERA':
            scene.camera = studio.camera_obj

        if studio.use_resolution:
            scene.render.resolution_x = studio.res_x
            scene.render.resolution_y = studio.res_y
            scene.render.resolution_percentage = studio.res_scale
            if scene.camera and scene.camera.data:
                scene.camera.data.sensor_fit = 'VERTICAL' if (studio.res_y > studio.res_x) else 'HORIZONTAL'

        if studio.use_lights:
            if studio.world_name:
                world = bpy.data.worlds.get(studio.world_name)
                if world:
                    scene.world = world

            switch_exclusive_studio_lights(context, studio)

            for l_item in studio.light_states:
                obj = bpy.data.objects.get(l_item.light_obj_name)
                if obj and obj.type == 'LIGHT':
                    obj.location = l_item.location
                    obj.rotation_euler = l_item.rotation_euler
                    obj.scale = l_item.scale
                    obj.data.energy = l_item.energy
                    obj.data.color = l_item.color
                    if hasattr(obj.data, "size"):
                        obj.data.size = l_item.size
                    obj.hide_set(l_item.hide_viewport)
                    obj.hide_render = l_item.hide_render

        if studio.use_collections:
            for st in studio.collection_states:
                coll = bpy.data.collections.get(st.name)
                if coll:
                    coll.hide_viewport = st.hide_viewport
                    coll.hide_render = st.hide_render

        if studio.use_transforms:
            for t_item in studio.object_transforms:
                obj = bpy.data.objects.get(t_item.object_name)
                if obj:
                    obj.location = t_item.location
                    obj.rotation_euler = t_item.rotation_euler
                    obj.scale = t_item.scale

        apply_cmf_to_scene(scene, studio)

        if studio.use_image_style:
            apply_image_style_to_scene(scene, studio)

        target_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, target_samples)
    finally:
        _IS_INTERNAL_UPDATE = prev_flag

# ------------------------------------------------------------------------
# Studio Operators
# ------------------------------------------------------------------------

class RENDERFLO_OT_toggle_render_preview(bpy.types.Operator):
    bl_idname = "renderflo.toggle_render_preview"
    bl_label = "Toggle Render Preview"

    def execute(self, context):
        configure_cycles_gpu(context.scene, force_gpu=context.scene.rf_force_gpu)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'SOLID' if space.shading.type == 'RENDERED' else 'RENDERED'
        return {'FINISHED'}

class RENDERFLO_OT_add_curved_backdrop(bpy.types.Operator):
    bl_idname = "renderflo.add_curved_backdrop"
    bl_label = "Add Studio Curved Backdrop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target = ensure_light_target(context)
        b_obj = bpy.data.objects.get(BACKDROP_OBJ_NAME)

        if not b_obj:
            mesh = bpy.data.meshes.new(BACKDROP_OBJ_NAME)
            w, d, h = 10.0, 6.0, 5.0
            verts = [(-w, -d, 0.0), (w, -d, 0.0), (w, d*0.5, 0.0), (-w, d*0.5, 0.0), (-w, d*0.5, h), (w, d*0.5, h)]
            faces = [(0, 1, 2, 3), (3, 2, 5, 4)]
            mesh.from_pydata(verts, [], faces)
            mesh.update()

            b_obj = bpy.data.objects.new(BACKDROP_OBJ_NAME, mesh)
            scene.collection.objects.link(b_obj)

            bev = b_obj.modifiers.new(name="Bevel", type='BEVEL')
            bev.width = 2.5
            bev.segments = 16

            sub = b_obj.modifiers.new(name="Subsurf", type='SUBSURF')
            sub.levels = 1

            for p in mesh.polygons:
                p.use_smooth = True

            mat = bpy.data.materials.new(name="RenderFlo_Backdrop_Mat")
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                if col_socket:
                    col_socket.default_value = (0.85, 0.85, 0.85, 1.0)
                rough_socket = bsdf.inputs.get("Roughness")
                if rough_socket:
                    rough_socket.default_value = 0.6
            b_obj.data.materials.append(mat)

        b_obj.location = (target.location.x, target.location.y, 0.0)
        self.report({'INFO'}, "Created/Aligned Studio Backdrop")
        return {'FINISHED'}

class RENDERFLO_OT_place_highlight_modal(bpy.types.Operator):
    bl_idname = "renderflo.place_highlight_modal"
    bl_label = "Click on Model to Place Highlight"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: bpy.props.StringProperty()
    distance: bpy.props.FloatProperty(default=2.5, min=0.2, max=20.0)

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)

            if result and obj and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                light_obj = bpy.data.objects.get(self.light_name)
                target = ensure_light_target(context)
                if light_obj:
                    incident = (location - ray_origin).normalized()
                    n = normal.normalized()
                    reflect_vec = (incident - 2.0 * incident.dot(n) * n).normalized()
                    dist = max((light_obj.location - target.location).length, self.distance)
                    light_obj.location = location + reflect_vec * dist
                    target.location = location

                if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                    context.window.cursor_modal_restore()
                    if 0 <= context.scene.rf_studio_index < len(context.scene.rf_studios):
                        capture_studio_state(context, context.scene.rf_studios[context.scene.rf_studio_index])
                    self.report({'INFO'}, f"Placed highlight on '{obj.name}'")
                    return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            context.window.cursor_modal_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'CANCELLED'}

class RENDERFLO_OT_snap_shadow_floor(bpy.types.Operator):
    bl_idname = "renderflo.snap_shadow_floor"
    bl_label = "Snap Shadow Catcher Floor to Product"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        min_z = None
        center_x, center_y = 0.0, 0.0
        mesh_count = 0

        depsgraph = context.evaluated_depsgraph_get()
        for obj in list(scene.objects):
            if obj.type == 'MESH' and obj.visible_get() and obj.name not in {GROUND_PLANE_NAME, BACKDROP_OBJ_NAME}:
                eval_obj = obj.evaluated_get(depsgraph)
                for corner in eval_obj.bound_box:
                    pt = eval_obj.matrix_world @ Vector(corner)
                    if min_z is None or pt.z < min_z:
                        min_z = pt.z
                center_x += obj.matrix_world.translation.x
                center_y += obj.matrix_world.translation.y
                mesh_count += 1

        if min_z is None:
            min_z = 0.0
        if mesh_count > 0:
            center_x /= mesh_count
            center_y /= mesh_count

        floor_obj = bpy.data.objects.get(GROUND_PLANE_NAME)
        if not floor_obj:
            bpy.ops.mesh.primitive_plane_add(size=25.0, location=(center_x, center_y, min_z))
            floor_obj = context.active_object
            floor_obj.name = GROUND_PLANE_NAME
        else:
            floor_obj.location = (center_x, center_y, min_z)

        floor_obj.is_shadow_catcher = True
        floor_obj.display_type = 'WIRE'
        self.report({'INFO'}, f"Shadow Catcher Floor snapped to Z = {min_z:.3f}")
        return {'FINISHED'}

class RENDERFLO_OT_add_studio(bpy.types.Operator):
    bl_idname = "renderflo.add_studio"
    bl_label = "Create New Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _IS_INTERNAL_UPDATE
        _IS_INTERNAL_UPDATE = True
        try:
            scene = context.scene
            prev_studio = scene.rf_studios[scene.rf_studio_index] if (0 <= scene.rf_studio_index < len(scene.rf_studios)) else None

            if len(scene.rf_cmf_presets) == 0:
                first_cmf = scene.rf_cmf_presets.add()
                first_cmf.name = "CMF_01_Default"
                record_materials_into_collection(scene, first_cmf.object_materials)

            new_studio = scene.rf_studios.add()
            new_studio.name = f"Studio_{len(scene.rf_studios):02d}"
            new_studio.studio_samples = scene.rf_render_samples

            if prev_studio:
                new_studio.aspect_preset = prev_studio.aspect_preset
                new_studio.base_resolution = prev_studio.base_resolution
                new_studio.res_x = prev_studio.res_x
                new_studio.res_y = prev_studio.res_y
                new_studio.res_scale = prev_studio.res_scale
                new_studio.exposure = prev_studio.exposure
                new_studio.film_transparent = prev_studio.film_transparent
            else:
                new_studio.res_x = scene.render.resolution_x
                new_studio.res_y = scene.render.resolution_y
                new_studio.exposure = scene.view_settings.exposure
                new_studio.film_transparent = scene.render.film_transparent

            if scene.rf_studio_new_cam_mode == 'NEW_VIEW':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)
            elif scene.rf_studio_new_cam_mode == 'NEW_COPY':
                new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=False)
            else:
                if prev_studio and prev_studio.camera_obj:
                    new_studio.camera_obj = prev_studio.camera_obj
                elif scene.camera:
                    new_studio.camera_obj = scene.camera
                else:
                    new_studio.camera_obj = create_camera_for_studio(context, new_studio.name, match_viewport=True)

            new_light_coll = ensure_studio_light_collection(context, new_studio)
            if scene.rf_studio_clone_lights and prev_studio and prev_studio.light_collection_name:
                prev_coll = bpy.data.collections.get(prev_studio.light_collection_name)
                if prev_coll:
                    for obj in list(prev_coll.objects):
                        if obj.type == 'LIGHT':
                            new_obj = obj.copy()
                            new_obj.data = obj.data.copy()
                            new_obj.name = f"{new_studio.name}_{obj.name}"
                            new_light_coll.objects.link(new_obj)

            if prev_studio and prev_studio.cmf_mode:
                new_studio.cmf_mode = prev_studio.cmf_mode
            else:
                new_studio.cmf_mode = scene.rf_cmf_presets[0].name

            scene.rf_studio_index = len(scene.rf_studios) - 1
            switch_exclusive_studio_lights(context, new_studio)
            capture_studio_state(context, new_studio)
            apply_studio_state(context, new_studio)
        finally:
            _IS_INTERNAL_UPDATE = False

        self.report({'INFO'}, f"ID RenderFlo: Created '{new_studio.name}'")
        return {'FINISHED'}

class RENDERFLO_OT_make_unique_camera(bpy.types.Operator):
    bl_idname = "renderflo.make_unique_camera"
    bl_label = "Spawn Dedicated Camera for This Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            studio.camera_obj = create_camera_for_studio(context, studio.name, match_viewport=False)
        return {'FINISHED'}

class RENDERFLO_OT_save_new_cmf(bpy.types.Operator):
    bl_idname = "renderflo.save_new_cmf"
    bl_label = "Save Current Materials as New CMF"
    bl_options = {'REGISTER', 'UNDO'}

    cmf_name: bpy.props.StringProperty(name="CMF Name", default="CMF_New_Colorway")

    def invoke(self, context, event):
        self.cmf_name = f"CMF_{len(context.scene.rf_cmf_presets) + 1:02d}"
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        new_cmf = scene.rf_cmf_presets.add()
        existing_names = {c.name for c in scene.rf_cmf_presets if c != new_cmf}
        base_name = self.cmf_name
        counter = 1
        while base_name in existing_names:
            base_name = f"{self.cmf_name}_{counter}"
            counter += 1
        new_cmf.name = base_name
        record_materials_into_collection(scene, new_cmf.object_materials)
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            scene.rf_studio_index = len(scene.rf_cmf_presets) - 1
            scene.rf_studios[scene.rf_studio_index].cmf_mode = new_cmf.name
        return {'FINISHED'}

class RENDERFLO_OT_update_active_cmf(bpy.types.Operator):
    bl_idname = "renderflo.update_active_cmf"
    bl_label = "Overwrite CMF Preset with Current Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            studio = scene.rf_studios[scene.rf_studio_index]
            if studio.cmf_mode == 'CUSTOM':
                record_materials_into_collection(scene, studio.object_materials)
            elif studio.cmf_mode != 'NONE':
                cmf = next((c for c in scene.rf_cmf_presets if c.name == studio.cmf_mode), None)
                if cmf:
                    record_materials_into_collection(scene, cmf.object_materials)
        return {'FINISHED'}

class RENDERFLO_OT_spawn_studio_light(bpy.types.Operator):
    bl_idname = "renderflo.spawn_studio_light"
    bl_label = "Add Studio Light"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        items=[
            ('KEY', "Key Softbox", "Primary 45-degree softbox light"),
            ('RIM', "Rim / Edge", "Back/Side high-contrast edge highlight light"),
            ('FILL', "Top Fill", "Soft overhead diffused fill light"),
        ],
        default='KEY'
    )

    def execute(self, context):
        scene = context.scene
        if not (0 <= scene.rf_studio_index < len(scene.rf_studios)):
            bpy.ops.renderflo.add_studio()

        studio = scene.rf_studios[scene.rf_studio_index]
        light_coll = ensure_studio_light_collection(context, studio)
        target = ensure_light_target(context)

        if self.preset == 'KEY':
            l_name, offset, energy, size, color = f"{studio.name}_KeyLight", Vector((2.2, -2.2, 1.8)), 150.0, 1.5, (1.0, 0.98, 0.95)
        elif self.preset == 'RIM':
            l_name, offset, energy, size, color = f"{studio.name}_RimLight", Vector((-2.0, 2.2, 1.2)), 250.0, 0.6, (0.95, 0.98, 1.0)
        else:
            l_name, offset, energy, size, color = f"{studio.name}_TopFill", Vector((0.0, 0.0, 3.0)), 80.0, 2.5, (1.0, 1.0, 1.0)

        light_data = bpy.data.lights.new(name=l_name, type='AREA')
        light_data.energy = energy
        light_data.size = size
        light_data.color = color
        light_data.shape = 'RECTANGLE'
        light_data.size_y = size * 0.65

        light_obj = bpy.data.objects.new(name=l_name, object_data=light_data)
        light_obj.location = target.location + offset
        light_coll.objects.link(light_obj)

        track = light_obj.constraints.new(type='TRACK_TO')
        track.target = target
        track.track_axis = 'TRACK_NEGATIVE_Z'
        track.up_axis = 'UP_Y'

        for o in context.selected_objects:
            o.select_set(False)
        light_obj.select_set(True)
        context.view_layer.objects.active = light_obj
        capture_studio_state(context, studio)
        return {'FINISHED'}

class RENDERFLO_OT_update_studio(bpy.types.Operator):
    bl_idname = "renderflo.update_studio"
    bl_label = "Update Studio State"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            capture_studio_state(context, studio)
        return {'FINISHED'}

class RENDERFLO_OT_activate_studio(bpy.types.Operator):
    bl_idname = "renderflo.activate_studio"
    bl_label = "Activate Studio"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        if 0 <= self.index < len(scene.rf_studios):
            studio = scene.rf_studios[self.index]
            scene.rf_studio_index = self.index
            apply_studio_state(context, studio)
        return {'FINISHED'}

class RENDERFLO_OT_remove_studio(bpy.types.Operator):
    bl_idname = "renderflo.remove_studio"
    bl_label = "Remove Studio"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.rf_studio_index
        if 0 <= idx < len(scene.rf_studios):
            studio = scene.rf_studios[idx]
            if studio.light_collection_name:
                coll = bpy.data.collections.get(studio.light_collection_name)
                if coll:
                    for obj in list(coll.objects):
                        bpy.data.objects.remove(obj, do_unlink=True)
                    bpy.data.collections.remove(coll)
            scene.rf_studios.remove(idx)
            scene.rf_studio_index = max(0, min(idx, len(scene.rf_studios) - 1))
            if len(scene.rf_studios) > 0:
                apply_studio_state(context, scene.rf_studios[scene.rf_studio_index])
        return {'FINISHED'}

class RENDERFLO_OT_select_target(bpy.types.Operator):
    bl_idname = "renderflo.select_target"
    bl_label = "Select Light Target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = ensure_light_target(context)
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}

class RENDERFLO_OT_activate_gpu_now(bpy.types.Operator):
    bl_idname = "renderflo.activate_gpu_now"
    bl_label = "Verify & Activate GPU Now"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        hw_label = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)
        apply_render_quality_settings(scene, scene.rf_render_samples)
        self.report({'INFO'}, f"ID RenderFlo: Render device set to {hw_label} @ {scene.rf_render_samples} Samples")
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Non-Blocking Modal Batch Render Queue
# ------------------------------------------------------------------------

class RENDERFLO_OT_cancel_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.cancel_batch_render"
    bl_label = "Cancel Batch Queue"

    def execute(self, context):
        context.scene.rf_is_batch_rendering = False
        return {'FINISHED'}

class RENDERFLO_OT_batch_render(bpy.types.Operator):
    bl_idname = "renderflo.batch_render"
    bl_label = "Batch Render Studios (GPU Modal Queue)"

    matrix_mode: bpy.props.BoolProperty(default=False)

    _timer = None
    _jobs = []
    _current_job_idx = 0
    _is_rendering_frame = False
    _frame_finished = False
    _render_cancelled = False
    _orig_filepath = ""
    _orig_res_x = 1920
    _orig_res_y = 1080
    _orig_res_scale = 100
    _orig_samples = 256
    _base_dir = ""

    def _on_render_complete(self, scene, depsgraph=None):
        self._frame_finished = True

    def _on_render_cancel(self, scene, depsgraph=None):
        self._render_cancelled = True

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None

        if self._on_render_complete in bpy.app.handlers.render_complete:
            bpy.app.handlers.render_complete.remove(self._on_render_complete)
        if self._on_render_cancel in bpy.app.handlers.render_cancel:
            bpy.app.handlers.render_cancel.remove(self._on_render_cancel)

        scene = context.scene
        scene.render.filepath = self._orig_filepath
        scene.render.resolution_x = self._orig_res_x
        scene.render.resolution_y = self._orig_res_y
        scene.render.resolution_percentage = self._orig_res_scale
        if hasattr(scene, "cycles"):
            scene.cycles.samples = self._orig_samples

        scene.rf_is_batch_rendering = False
        scene.rf_batch_status_text = ""
        for area in context.screen.areas:
            area.tag_redraw()

    def invoke(self, context, event):
        scene = context.scene
        if scene.rf_is_batch_rendering:
            self.report({'WARNING'}, "Batch Render is already running!")
            return {'CANCELLED'}

        self._orig_filepath = scene.render.filepath
        if not self._orig_filepath:
            self.report({'ERROR'}, "Please set an Output Folder in Render Output Properties first.")
            return {'CANCELLED'}

        self._base_dir = bpy.path.abspath(self._orig_filepath)
        if not self._base_dir.endswith(os.sep):
            base_dir = os.path.dirname(self._base_dir)
            self._base_dir = base_dir
        os.makedirs(self._base_dir, exist_ok=True)

        self._orig_res_x = scene.render.resolution_x
        self._orig_res_y = scene.render.resolution_y
        self._orig_res_scale = scene.render.resolution_percentage
        self._orig_samples = scene.cycles.samples if hasattr(scene, "cycles") else 256

        hw_status = configure_cycles_gpu(scene, force_gpu=scene.rf_force_gpu)

        self._jobs = []
        active_cmfs = [c for c in scene.rf_cmf_presets if c.batch_enabled]

        for s_idx, studio in enumerate(scene.rf_studios):
            if not studio.render_enabled:
                continue
            s_name = bpy.path.clean_name(studio.name)
            res_tag = f"{studio.res_x}x{studio.res_y}"

            if self.matrix_mode and len(active_cmfs) > 0:
                for cmf in active_cmfs:
                    c_name = bpy.path.clean_name(cmf.name)
                    out_path = os.path.join(self._base_dir, f"{s_name}_{c_name}_{res_tag}")
                    self._jobs.append((s_idx, cmf.name, out_path, f"{studio.name} + {cmf.name}"))
            else:
                out_path = os.path.join(self._base_dir, f"{s_name}_{res_tag}")
                self._jobs.append((s_idx, None, out_path, f"{studio.name}"))

        if not self._jobs:
            self.report({'WARNING'}, "No checked Studios to render.")
            return {'CANCELLED'}

        if not scene.camera and not any(s.camera_obj for s in scene.rf_studios):
            self.report({'ERROR'}, "No Camera in scene! Please assign or create a Studio Camera first.")
            return {'CANCELLED'}

        self._current_job_idx = 0
        self._is_rendering_frame = False
        self._frame_finished = False
        self._render_cancelled = False

        bpy.app.handlers.render_complete.append(self._on_render_complete)
        bpy.app.handlers.render_cancel.append(self._on_render_cancel)

        scene.rf_is_batch_rendering = True
        scene.rf_batch_progress = 0.0
        scene.rf_batch_status_text = f"Starting {hw_status} Queue (0 / {len(self._jobs)})..."

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene

        if event.type == 'ESC' or self._render_cancelled or not scene.rf_is_batch_rendering:
            self._cleanup(context)
            self.report({'WARNING'}, "Batch Render Cancelled.")
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        if self._is_rendering_frame:
            if self._frame_finished:
                self._is_rendering_frame = False
                self._frame_finished = False
                self._current_job_idx += 1
            else:
                return {'PASS_THROUGH'}

        total_jobs = len(self._jobs)
        if self._current_job_idx >= total_jobs:
            self._cleanup(context)
            self.report({'INFO'}, f"ID RenderFlo: Batch Render Complete! ({total_jobs} images saved to {self._base_dir})")
            return {'FINISHED'}

        s_idx, cmf_override, out_path, job_label = self._jobs[self._current_job_idx]
        studio = scene.rf_studios[s_idx]

        scene.rf_studio_index = s_idx
        apply_studio_state(context, studio)

        if cmf_override:
            cmf = next((c for c in scene.rf_cmf_presets if c.name == cmf_override), None)
            if cmf:
                restore_materials_from_collection(cmf.object_materials)

        shot_samples = studio.studio_samples if studio.use_custom_samples else scene.rf_render_samples
        apply_render_quality_settings(scene, shot_samples)
        scene.render.filepath = out_path

        scene.rf_batch_progress = (self._current_job_idx / total_jobs) * 100.0
        scene.rf_batch_status_text = f"Rendering [{self._current_job_idx + 1}/{total_jobs}]: {job_label} ({shot_samples} samples)"
        for area in context.screen.areas:
            area.tag_redraw()

        self._is_rendering_frame = True
        self._frame_finished = False

        res = bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
        if 'RUNNING_MODAL' not in res:
            bpy.ops.render.render(write_still=True)
            self._frame_finished = True

        return {'PASS_THROUGH'}

# ------------------------------------------------------------------------
# UI Lists & Sidebar Panel
# ------------------------------------------------------------------------

class RENDERFLO_UL_studio_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "render_enabled", text="")
            row.prop(item, "name", text="", emboss=False, icon='RENDERLAYERS')

            sub = row.row(align=True)
            sub.scale_x = 0.85
            aspect_tag = item.aspect_preset.replace('_', ':') if item.aspect_preset != 'CUSTOM' else f"{item.res_x}x{item.res_y}"
            cam_label = item.camera_obj.name if item.camera_obj else "NoCam"
            sub.label(text=f"[{aspect_tag} | {cam_label}]")

            op_act = row.operator("renderflo.activate_studio", text="", icon='PLAY')
            op_act.index = index
            op_upd = row.operator("renderflo.update_studio", text="", icon='FILE_REFRESH')
            op_upd.index = index

class RENDERFLO_PT_main_panel(bpy.types.Panel):
    bl_label = "ID RenderFlo"
    bl_idname = "RENDERFLO_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ID RenderFlo'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        top_row = layout.row(align=True)
        top_row.operator("renderflo.toggle_render_preview", icon='SHADING_RENDERED', text="Toggle Viewport Render Preview")

        # 0. NATIVE CAD BRIDGE BOX
        cad_box = layout.box()
        ready = is_cad_engine_ready()
        cad_header = cad_box.row(align=True)
        cad_header.label(text="Native CAD Engine Active" if ready else "CAD Engine Setup Ready", icon='CHECKMARK' if ready else 'INFO')

        cad_col = cad_box.column(align=True)
        imp_row = cad_col.row(align=True)
        imp_row.scale_y = 1.3
        imp_row.operator("renderflo.import_cad", icon='IMPORT', text="Import CAD (.STEP / .IGES / .STL)")

        if not ready:
            cad_col.operator("renderflo.bootstrap_cad_kernel", icon='PREFERENCES', text="Verify & Download CAD Engine")

        # 1. Create Studio Controls
        create_box = layout.box()
        col = create_box.column(align=True)
        row = col.row(align=True)
        row.scale_y = 1.3
        row.operator("renderflo.add_studio", icon='ADD', text="Create New Studio")

        col.separator()
        col.label(text="On New Studio:", icon='SETTINGS')
        col.prop(scene, "rf_studio_new_cam_mode", text="Cam")
        col.prop(scene, "rf_studio_clone_lights", text="Clone Current Studio Lights")

        # 2. Studio List
        row = layout.row()
        row.template_list("RENDERFLO_UL_studio_list", "", scene, "rf_studios", scene, "rf_studio_index", rows=5)

        col = row.column(align=True)
        col.operator("renderflo.remove_studio", icon='REMOVE', text="")
        col.separator()
        col.operator("renderflo.snap_shadow_floor", icon='IMPORT', text="")

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            active_studio = scene.rf_studios[scene.rf_studio_index]

            # 3. PER-STUDIO ASPECT RATIO & FORMAT
            res_box = layout.box()
            res_header = res_box.row(align=True)
            res_header.label(text=f"1. Format & Aspect ({active_studio.res_x}x{active_studio.res_y})", icon='FULLSCREEN_ENTER')
            res_header.prop(active_studio, "use_resolution", text="")

            if active_studio.use_resolution:
                res_col = res_box.column(align=True)
                res_col.prop(active_studio, "aspect_preset", text="Ratio")
                if active_studio.aspect_preset == 'CUSTOM':
                    xy_row = res_col.row(align=True)
                    xy_row.prop(active_studio, "res_x", text="W")
                    xy_row.prop(active_studio, "res_y", text="H")
                else:
                    res_col.prop(active_studio, "base_resolution", text="Long Edge (px)")
                res_col.prop(active_studio, "res_scale", text="Render Scale")

            # 4. CAMERA MODULE
            cam_box = layout.box()
            cam_header = cam_box.row(align=True)
            cam_header.label(text="2. Studio Camera", icon='CAMERA_DATA')

            if active_studio.camera_obj:
                shared_count = sum(1 for s in scene.rf_studios if s.camera_obj == active_studio.camera_obj)
                cam_header.label(text=f"Shared ({shared_count})" if shared_count > 1 else "Unique", icon='LINKED' if shared_count > 1 else 'UNLINKED')
            cam_header.prop(active_studio, "use_camera", text="")

            if active_studio.use_camera:
                cam_row = cam_box.row(align=True)
                cam_row.prop(active_studio, "camera_obj", text="")
                cam_row.operator("renderflo.make_unique_camera", text="", icon='DUPLICATE')

                if active_studio.camera_obj and active_studio.camera_obj.type == 'CAMERA':
                    cam_data = active_studio.camera_obj.data
                    cam_settings = cam_box.row(align=True)
                    cam_settings.prop(cam_data, "lens", text="Focal (mm)")
                    if context.space_data and context.space_data.type == 'VIEW_3D':
                        cam_settings.prop(context.space_data, "lock_camera", text="Lock View", icon='LOCKVIEW_ON')

            # 5. CMF MODULE
            cmf_box = layout.box()
            cmf_header = cmf_box.row(align=True)
            cmf_header.label(text="3. CMF (Colorway)", icon='MATERIAL')
            cmf_header.prop(active_studio, "use_materials", text="")

            if active_studio.use_materials:
                cmf_row = cmf_box.row(align=True)
                cmf_row.prop(active_studio, "cmf_mode", text="")
                cmf_row.operator("renderflo.update_active_cmf", text="", icon='FILE_REFRESH')
                cmf_row.operator("renderflo.save_new_cmf", text="+ New CMF", icon='ADD')

                active_obj = context.active_object
                if active_obj and active_obj.type == 'MESH' and active_obj.active_material:
                    mat_box = cmf_box.box()
                    mat_box.label(text=f"Selected Part: {active_obj.name}", icon='OBJECT_DATA')
                    m_row = mat_box.row(align=True)
                    m_row.prop(active_obj, "active_material", text="")
                    m_row.operator("renderflo.clone_active_material", text="Clone", icon='DUPLICATE')

                    bsdf = active_obj.active_material.node_tree.nodes.get("Principled BSDF") if active_obj.active_material.use_nodes else None
                    if bsdf:
                        col_socket = bsdf.inputs.get("Base Color") or bsdf.inputs.get("Color")
                        if col_socket:
                            mat_box.prop(col_socket, "default_value", text="Color")

                if len(scene.rf_cmf_presets) > 0:
                    cmf_list_col = cmf_box.column(align=True)
                    cmf_list_col.label(text="Matrix Batch Colorways:")
                    grid = cmf_list_col.grid_flow(columns=2, align=True)
                    for cmf in scene.rf_cmf_presets:
                        grid.prop(cmf, "batch_enabled", text=cmf.name)

            # 6. LIGHTING MODULE
            light_box = layout.box()
            l_header = light_box.row(align=True)
            l_header.label(text=f"4. Lighting Rig ({active_studio.name})", icon='LIGHT_AREA')
            l_header.operator("renderflo.select_target", text="", icon='PIVOT_CURSOR')
            l_header.prop(active_studio, "use_lights", text="")

            if active_studio.use_lights:
                spawn_row = light_box.row(align=True)
                op_key = spawn_row.operator("renderflo.spawn_studio_light", text="+ Key", icon='LIGHT_SUN')
                op_key.preset = 'KEY'
                op_rim = spawn_row.operator("renderflo.spawn_studio_light", text="+ Rim", icon='LIGHT_SPOT')
                op_rim.preset = 'RIM'
                op_fill = spawn_row.operator("renderflo.spawn_studio_light", text="+ Fill", icon='LIGHT_HEMI')
                op_fill.preset = 'FILL'

                studio_coll = bpy.data.collections.get(active_studio.light_collection_name)
                if studio_coll and len(studio_coll.objects) > 0:
                    l_col = light_box.column(align=True)
                    for l_obj in studio_coll.objects:
                        if l_obj.type == 'LIGHT':
                            l_row = l_col.row(align=True)
                            l_row.prop(l_obj, "hide_viewport", text="", emboss=False)
                            l_row.prop(l_obj, "name", text="")
                            l_row.prop(l_obj.data, "energy", text="W")
                            l_row.prop(l_obj.data, "color", text="")
                            op_hl = l_row.operator("renderflo.place_highlight_modal", text="", icon='EYEDROPPER')
                            op_hl.light_name = l_obj.name

            # 7. ENVIRONMENT & STUDIO BACKDROP
            env_box = layout.box()
            env_box.label(text="5. Environment, Floor & Backdrop", icon='SCENE_DATA')
            style_row = env_box.row(align=True)
            style_row.prop(active_studio, "exposure", text="Exposure")
            style_row.prop(active_studio, "film_transparent", text="Transparent PNG")
            toggle_row = env_box.row(align=True)
            toggle_row.prop(active_studio, "use_collections", text="Model Sets")
            toggle_row.prop(active_studio, "use_transforms", text="Exploded / Part Pos")

            floor_row = env_box.row(align=True)
            floor_row.operator("renderflo.snap_shadow_floor", icon='MESH_PLANE', text="Floor Shadow Catcher")
            floor_row.operator("renderflo.add_curved_backdrop", icon='MOD_BEVEL', text="Curved Backdrop")

        layout.separator()

        # 8. GPU HARDWARE & SAMPLE CONTROLS
        gpu_box = layout.box()
        gpu_header = gpu_box.row(align=True)
        dev_str = scene.cycles.device if hasattr(scene, "cycles") else "N/A"
        gpu_header.label(text=f"6. GPU & Render Quality ({dev_str})", icon='SHADING_RENDERED')

        gpu_col = gpu_box.column(align=True)
        hw_row = gpu_col.row(align=True)
        hw_row.prop(scene, "rf_force_gpu", text="Force GPU Compute")
        hw_row.operator("renderflo.activate_gpu_now", text="Activate GPU", icon='CHECKMARK')

        samp_row = gpu_col.row(align=True)
        samp_row.prop(scene, "rf_render_samples", text="Render Samples")
        samp_row.prop(scene, "rf_viewport_samples", text="Viewport")

        dn_row = gpu_col.row(align=True)
        dn_row.prop(scene, "rf_use_denoiser", text="Denoiser")
        dn_row.prop(scene, "rf_noise_threshold", text="Noise Limit")

        if 0 <= scene.rf_studio_index < len(scene.rf_studios):
            active_studio = scene.rf_studios[scene.rf_studio_index]
            ovr_row = gpu_col.row(align=True)
            ovr_row.prop(active_studio, "use_custom_samples", text=f"Custom Samples for '{active_studio.name}'")
            if active_studio.use_custom_samples:
                ovr_row.prop(active_studio, "studio_samples", text="Samples")

        # 9. Non-Blocking Modal Batch Render Queue
        render_box = layout.box()
        render_col = render_box.column(align=True)

        if scene.rf_is_batch_rendering:
            render_col.label(text=scene.rf_batch_status_text, icon='TIME')
            render_col.prop(scene, "rf_batch_progress", text="Batch Progress", slider=True)
            cancel_row = render_col.row(align=True)
            cancel_row.scale_y = 1.4
            cancel_row.operator("renderflo.cancel_batch_render", icon='CANCEL', text="Cancel Batch Render (or Press ESC)")
        else:
            btn_std = render_col.row(align=True)
            btn_std.scale_y = 1.4
            op_std = btn_std.operator("renderflo.batch_render", icon='RENDER_STILL', text="Batch Render Checked Studios (GPU)")
            op_std.matrix_mode = False

            btn_mat = render_col.row(align=True)
            btn_mat.scale_y = 1.3
            op_mat = btn_mat.operator("renderflo.batch_render", icon='GRID', text="Matrix Render (Studios x CMFs)")
            op_mat.matrix_mode = True

def menu_func_import_cad(self, context):
    self.layout.operator(RENDERFLO_OT_import_cad.bl_idname, text="CAD Assembly (.step, .stp, .iges, .stl)")

classes = (
    RENDERFLO_PG_collection_state,
    RENDERFLO_PG_material_slot,
    RENDERFLO_PG_object_materials,
    RENDERFLO_PG_object_transform,
    RENDERFLO_PG_cmf_preset,
    RENDERFLO_PG_light_state,
    RENDERFLO_PG_studio_item,
    RENDERFLO_OT_clone_active_material,
    RENDERFLO_OT_toggle_render_preview,
    RENDERFLO_OT_add_curved_backdrop,
    RENDERFLO_OT_bootstrap_cad_kernel,
    RENDERFLO_OT_import_cad,
    RENDERFLO_OT_place_highlight_modal,
    RENDERFLO_OT_snap_shadow_floor,
    RENDERFLO_OT_add_studio,
    RENDERFLO_OT_make_unique_camera,
    RENDERFLO_OT_save_new_cmf,
    RENDERFLO_OT_update_active_cmf,
    RENDERFLO_OT_spawn_studio_light,
    RENDERFLO_OT_update_studio,
    RENDERFLO_OT_activate_studio,
    RENDERFLO_OT_remove_studio,
    RENDERFLO_OT_select_target,
    RENDERFLO_OT_activate_gpu_now,
    RENDERFLO_OT_cancel_batch_render,
    RENDERFLO_OT_batch_render,
    RENDERFLO_UL_studio_list,
    RENDERFLO_PT_main_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import_cad)

    bpy.types.Scene.rf_studios = bpy.props.CollectionProperty(type=RENDERFLO_PG_studio_item)
    bpy.types.Scene.rf_cmf_presets = bpy.props.CollectionProperty(type=RENDERFLO_PG_cmf_preset)
    bpy.types.Scene.rf_studio_index = bpy.props.IntProperty(name="Active Studio Index", default=0)

    bpy.types.Scene.rf_studio_new_cam_mode = bpy.props.EnumProperty(
        name="New Studio Camera",
        items=[
            ('LINK_CURRENT', "Link Current Camera (Shared)", "Use the exact same Camera object as the current Studio"),
            ('NEW_COPY', "Spawn New Camera (Copy Angle)", "Create a new independent Camera starting at the current camera's angle"),
            ('NEW_VIEW', "Spawn New Camera (From 3D View)", "Create a new independent Camera matching your current 3D Viewport angle"),
        ],
        default='LINK_CURRENT'
    )
    bpy.types.Scene.rf_studio_clone_lights = bpy.props.BoolProperty(name="Clone Current Studio Lights", default=False)

    bpy.types.Scene.rf_force_gpu = bpy.props.BoolProperty(
        name="Force GPU Compute",
        description="Configure Cycles to use dedicated GPU (OptiX / CUDA / HIP / Metal)",
        default=True,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_render_samples = bpy.props.IntProperty(
        name="Render Samples",
        description="Cycles sample count for final Studio renders",
        default=256,
        min=1,
        max=65536,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_viewport_samples = bpy.props.IntProperty(
        name="Viewport Samples",
        description="Cycles sample count for 3D Viewport preview",
        default=64,
        min=1,
        max=4096,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_use_denoiser = bpy.props.BoolProperty(
        name="Use Denoiser",
        description="Enable Cycles AI Denoising for clean studio renders",
        default=True,
        update=update_global_render_settings
    )
    bpy.types.Scene.rf_noise_threshold = bpy.props.FloatProperty(
        name="Adaptive Noise Limit",
        description="Stop sampling pixels once they reach this noise threshold",
        default=0.01,
        min=0.0001,
        max=1.0,
        update=update_global_render_settings
    )

    bpy.types.Scene.rf_is_batch_rendering = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.rf_batch_progress = bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    bpy.types.Scene.rf_batch_status_text = bpy.props.StringProperty(default="")

def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import_cad)
    for prop in (
        "rf_batch_status_text", "rf_batch_progress", "rf_is_batch_rendering",
        "rf_noise_threshold", "rf_use_denoiser", "rf_viewport_samples",
        "rf_render_samples", "rf_force_gpu", "rf_studio_clone_lights",
        "rf_studio_new_cam_mode", "rf_studio_index", "rf_cmf_presets", "rf_studios"
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()